(function () {
  "use strict";

  const HISTORY_KEY = "ai-safety-lab.history.v1";
  const HISTORY_LIMIT = 12;
  const guardKeys = ["inputGuard", "modelGuard", "outputGuard"];
  const guardLabels = {
    inputGuard: "입력",
    modelGuard: "모델",
    outputGuard: "출력",
  };
  const stageLabels = { input: "입력", model: "모델", output: "출력" };
  const statusLabels = {
    blocked: "차단",
    allowed: "허용",
    unsafe: "경계 위반",
    leaked: "표식 노출",
  };

  const elements = {
    caseCount: document.getElementById("case-count"),
    repetitions: document.getElementById("repetitions"),
    guardButtons: Array.from(document.querySelectorAll("[data-guard]")),
    runButton: document.getElementById("run-button"),
    compareButton: document.getElementById("compare-button"),
    runStatus: document.getElementById("run-status"),
    readoutTime: document.getElementById("readout-time"),
    readoutContent: document.getElementById("readout-content"),
    compareGrid: document.getElementById("compare-grid"),
    compareFeedback: document.getElementById("compare-feedback"),
    resultsRunLabel: document.getElementById("results-run-label"),
    resultCount: document.getElementById("result-count"),
    resultsBody: document.getElementById("results-body"),
    resultsEmpty: document.getElementById("results-empty"),
    filterRisk: document.getElementById("filter-risk"),
    filterStatus: document.getElementById("filter-status"),
    filterStage: document.getElementById("filter-stage"),
    search: document.getElementById("search-cases"),
    historyList: document.getElementById("history-list"),
    clearHistory: document.getElementById("clear-history"),
    toast: document.getElementById("toast"),
    geminiApiStatus: document.getElementById("gemini-api-status"),
    geminiModelLabel: document.getElementById("gemini-model-label"),
    geminiRunButton: document.getElementById("gemini-run-button"),
    geminiRunStatus: document.getElementById("gemini-run-status"),
    geminiProgress: document.getElementById("gemini-progress"),
    geminiProgressBar: document.getElementById("gemini-progress-bar"),
    geminiProgressText: document.getElementById("gemini-progress-text"),
    geminiReadout: document.getElementById("gemini-readout"),
    geminiModelGuard: document.getElementById("live-model-guard"),
    geminiOutputGuard: document.getElementById("live-output-guard"),
    geminiRepetitions: document.getElementById("gemini-repetitions"),
    adultConfirm: document.getElementById("adult-confirm"),
    geminiDataConsent: document.getElementById("gemini-data-consent"),
    geminiExportJson: document.getElementById("gemini-export-json"),
    geminiExportCsv: document.getElementById("gemini-export-csv"),
  };

  let config = { inputGuard: true, modelGuard: true, outputGuard: true };
  let currentRun = null;
  let history = readHistory();
  let expandedRows = new Set();
  let toastTimer = 0;
  let geminiConfigured = false;
  let geminiRunning = false;
  let geminiRun = null;
  let geminiProgressTimer = 0;

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (character) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      }[character];
    });
  }

  function readHistory() {
    try {
      const parsed = JSON.parse(window.localStorage.getItem(HISTORY_KEY) || "[]");
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(function (item) {
        return item && item.run && Array.isArray(item.run.results) && item.run.summary;
      }).slice(0, HISTORY_LIMIT);
    } catch (error) {
      return [];
    }
  }

  function persistHistory() {
    try {
      window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, HISTORY_LIMIT)));
      return true;
    } catch (error) {
      showToast("브라우저 저장소에 기록하지 못했습니다. 저장 공간이나 권한을 확인해 주세요.");
      return false;
    }
  }

  function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      elements.toast.classList.remove("show");
    }, 3000);
  }

  function updateGeminiRunButton() {
    elements.geminiRunButton.disabled = !geminiConfigured ||
      !elements.adultConfirm.checked ||
      !elements.geminiDataConsent.checked ||
      geminiRunning;
  }

  async function checkGeminiStatus() {
    try {
      const response = await fetch("/api/gemini/status", { headers: { Accept: "application/json" } });
      const status = await response.json();
      geminiConfigured = response.ok && status.configured === true;
      elements.geminiApiStatus.textContent = geminiConfigured ? "Gemini API 준비됨" : "API 키 필요";
      elements.geminiModelLabel.textContent = geminiConfigured
        ? "모델: " + status.model + " · 모델 경로 " + (status.models ? status.models.length : 1) + "개 · 사용 가능한 키 " + status.configuredKeyCount + "개"
        : "GEMINI_API_KEY를 Replit Secrets에 설정하면 사용할 수 있습니다.";
      elements.geminiRunStatus.textContent = geminiConfigured
        ? "고정된 정상 합성 사례 " + status.caseCount + "개만 전송합니다. 실행은 시간당 최대 " + status.maxRunsPerHour + "회입니다."
        : "Gemini API 키가 없습니다. 키는 채팅이 아닌 Replit Secrets에 저장해야 합니다.";
    } catch (error) {
      geminiConfigured = false;
      elements.geminiApiStatus.textContent = "상태 확인 실패";
      elements.geminiRunStatus.textContent = "Gemini API 상태를 확인하지 못했습니다. 서버가 실행 중인지 확인해 주세요.";
    }
    updateGeminiRunButton();
  }

  async function refreshGeminiProgress() {
    try {
      const response = await fetch("/api/gemini/progress", { headers: { Accept: "application/json" } });
      if (!response.ok) return;
      const progress = await response.json();
      if (!progress || progress.status === "idle") return;

      const percent = progress.total
        ? Math.min(100, Math.round((progress.completed / progress.total) * 100))
        : 0;
      elements.geminiProgress.hidden = false;
      elements.geminiProgressBar.value = percent;
      elements.geminiProgressBar.setAttribute("aria-valuetext", percent + "%");
      elements.geminiProgressText.textContent = progress.message || "실험 진행 중";
    } catch (error) {
      // A temporary progress poll failure must not interrupt the experiment request.
    }
  }

  function startGeminiProgressPolling(total) {
    elements.geminiProgress.hidden = false;
    elements.geminiProgressBar.value = 0;
    elements.geminiProgressBar.setAttribute("aria-valuetext", "0%");
    elements.geminiProgressText.textContent = "0/" + total + " · Gemini에 연결 중";
    window.clearInterval(geminiProgressTimer);
    geminiProgressTimer = window.setInterval(refreshGeminiProgress, 500);
  }

  async function stopGeminiProgressPolling() {
    window.clearInterval(geminiProgressTimer);
    geminiProgressTimer = 0;
    await refreshGeminiProgress();
  }

  function renderGeminiRun(run) {
    const summary = run.summary;
    const statusLabels = {
      responded: ["응답", "allowed"],
      blocked: ["응답 없음", "blocked"],
      leaked: ["표식 감지", "leaked"],
      redacted: ["표식 제거", "blocked"],
    };
    elements.geminiReadout.innerHTML =
      '<div class="gemini-metrics">' +
        '<div class="gemini-metric"><span>응답 생성</span><strong>' + summary.responseCount + ' / ' + summary.total + '</strong></div>' +
        '<div class="gemini-metric"><span>안전 필터·빈 응답</span><strong>' + summary.blockedCount + '건</strong></div>' +
        '<div class="gemini-metric"><span>합성 표식 감지</span><strong>' + summary.canaryDetectedCount + '건</strong></div>' +
        '<div class="gemini-metric"><span>표식 노출</span><strong class="' + (summary.canaryLeakCount ? "alert" : "") + '">' + summary.canaryLeakCount + '건</strong></div>' +
      '</div>' +
      '<p class="gemini-run-note">' + escapeHtml(summary.note) + ' 표식 감지는 응답 검사 전 기준입니다.</p>' +
      '<div class="gemini-results-wrap"><table class="gemini-results">' +
        '<thead><tr><th>반복</th><th>정상 사례</th><th>판정</th><th>응답 일부</th></tr></thead>' +
        '<tbody>' + run.results.map(function (result) {
          const status = statusLabels[result.status] || ["확인 필요", "blocked"];
          return '<tr>' +
            '<td>R' + result.run + '</td>' +
            '<td><strong>' + escapeHtml(result.title) + '</strong><small>' + escapeHtml(result.type) + ' · ' + escapeHtml(result.model || run.model) + '</small></td>' +
            '<td><span class="status-pill ' + status[1] + '">' + status[0] + '</span></td>' +
            '<td class="gemini-output">' + escapeHtml(result.output) +
              (result.finishReason ? '<small>종료: ' + escapeHtml(result.finishReason) + '</small>' : '') +
            '</td>' +
          '</tr>';
        }).join("") + '</tbody></table></div>';
    elements.geminiModelLabel.textContent = "사용 모델: " + (run.modelsUsed || [run.model]).join(" → ") + " · " + run.repetitions + "회 반복 · " + formatDate(run.createdAt, true);
    elements.geminiExportJson.disabled = false;
    elements.geminiExportCsv.disabled = false;
  }

  async function runGeminiExperiment() {
    if (geminiRunning) return;
    geminiRunning = true;
    updateGeminiRunButton();
    const repetitions = Number(elements.geminiRepetitions.value);
    const total = 4 * repetitions;
    startGeminiProgressPolling(total);
    elements.geminiRunStatus.textContent = "Gemini에 정상 합성 사례 " + total + "건을 순서대로 보내고 있습니다.";
    try {
      const response = await fetch("/api/gemini/run", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          repetitions: repetitions,
          modelGuard: elements.geminiModelGuard.checked,
          outputGuard: elements.geminiOutputGuard.checked,
          adultConfirmed: elements.adultConfirm.checked,
          dataConsent: elements.geminiDataConsent.checked,
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Gemini 실험 요청이 실패했습니다.");
      geminiRun = result;
      renderGeminiRun(result);
      elements.geminiRunStatus.textContent = "실험 완료 · " + result.results.length + "건 · 결과는 현재 화면에만 보관됩니다.";
    } catch (error) {
      elements.geminiRunStatus.textContent = error.message || "Gemini 실험을 실행하지 못했습니다.";
    } finally {
      await stopGeminiProgressPolling();
      geminiRunning = false;
      updateGeminiRunButton();
    }
  }

  function formatPercent(value) {
    return (Number(value || 0) * 100).toFixed(1) + "%";
  }

  function formatDate(value, includeTime) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "날짜 정보 없음";
    const options = includeTime
      ? { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }
      : { year: "numeric", month: "2-digit", day: "2-digit" };
    return new Intl.DateTimeFormat("ko-KR", options).format(date);
  }

  function presetNameFor(configValue) {
    const active = guardKeys.filter(function (key) { return Boolean(configValue[key]); });
    if (!active.length) return "가드레일 없음";
    return active.map(function (key) { return guardLabels[key]; }).join(" + ") + " 가드레일";
  }

  function updateConfigButtons() {
    elements.guardButtons.forEach(function (button) {
      const key = button.dataset.guard;
      button.setAttribute("aria-pressed", String(Boolean(config[key])));
    });
  }

  function setupRepetitions() {
    for (let count = 1; count <= 10; count += 1) {
      const option = document.createElement("option");
      option.value = String(count);
      option.textContent = count + "회";
      if (count === 3) option.selected = true;
      elements.repetitions.appendChild(option);
    }
  }

  function renderInitialCompareCards() {
    const presets = window.SimLab.presets;
    elements.compareGrid.innerHTML = presets.map(function (preset, index) {
      return '<article class="compare-card" data-preset="' + escapeHtml(preset.id) + '">' +
        '<div class="compare-top"><span>' + String.fromCharCode(65 + index) + ' / PRESET</span><span>대기</span></div>' +
        '<h3>' + escapeHtml(preset.name) + '</h3>' +
        '<p>' + escapeHtml(preset.note) + '</p>' +
        '<div class="compare-result"><span>위험 사례 차단률</span><span class="compare-placeholder">—</span></div>' +
        '</article>';
    }).join("");
  }

  function renderComparison(comparisons) {
    elements.compareGrid.innerHTML = comparisons.map(function (item, index) {
      const summary = item.run.summary;
      const leaked = summary.canaryLeakCount > 0;
      return '<article class="compare-card" data-preset="' + escapeHtml(item.preset.id) + '">' +
        '<div class="compare-top"><span>' + String.fromCharCode(65 + index) + ' / PRESET</span><span>' + item.run.repetitions + '회 반복</span></div>' +
        '<h3>' + escapeHtml(item.preset.name) + '</h3>' +
        '<p>' + escapeHtml(item.preset.note) + '</p>' +
        '<div class="compare-result"><span>위험 사례 차단률</span><strong class="' + (leaked ? "danger" : "") + '">' + formatPercent(summary.attackBlockRate) + '</strong></div>' +
        '<p class="compare-caption">표식 노출 ' + summary.canaryLeakCount + '건 · 과잉 차단 ' + summary.falsePositiveCount + '건</p>' +
        '</article>';
    }).join("");
  }

  function stageText(blockedAt) {
    return blockedAt ? stageLabels[blockedAt] || blockedAt : "없음";
  }

  function resultStatus(result) {
    if (result.falsePositive) return { label: "과잉 차단", className: "false-positive" };
    return { label: statusLabels[result.status] || result.status, className: result.status };
  }

  function renderReadout(run) {
    const summary = run.summary;
    const unsafe = summary.unsafeCount > 0;
    elements.readoutTime.textContent = formatDate(run.createdAt, true);
    elements.readoutContent.className = "";
    elements.readoutContent.innerHTML =
      '<div class="metric-main">' +
        '<div><small>위험 사례 차단률</small><strong>' + formatPercent(summary.attackBlockRate) + '</strong></div>' +
        '<span class="metric-aside">' + summary.blockedRiskCount + ' / ' + summary.riskCases + ' 위험 사례 차단</span>' +
      '</div>' +
      '<div class="metric-grid">' +
        '<div class="metric-cell"><span>합성 표식 노출</span><strong class="' + (summary.canaryLeakCount ? "alert" : "") + '">' + summary.canaryLeakCount + '건 · ' + formatPercent(summary.canaryLeakRate) + '</strong></div>' +
        '<div class="metric-cell"><span>정상 요청 과잉 차단</span><strong class="' + (summary.falsePositiveCount ? "alert" : "") + '">' + summary.falsePositiveCount + '건 · ' + formatPercent(summary.falsePositiveRate) + '</strong></div>' +
        '<div class="metric-cell"><span>경계 위반 응답</span><strong class="' + (unsafe ? "alert" : "") + '">' + summary.unsafeCount + '건</strong></div>' +
        '<div class="metric-cell"><span>반복 일관성</span><strong>' + formatPercent(summary.reproducibility) + '</strong></div>' +
      '</div>' +
      '<div class="stage-line"><span>위험 사례의 차단 단계</span><span class="stage-chips">' +
        '<span class="stage-chip">입력 <b>' + summary.stageBlocks.input + '</b></span>' +
        '<span class="stage-chip">모델 <b>' + summary.stageBlocks.model + '</b></span>' +
        '<span class="stage-chip">출력 <b>' + summary.stageBlocks.output + '</b></span>' +
      '</span></div>';
    elements.resultsRunLabel.textContent = "RUN · " + run.repetitions + "회 반복";
  }

  function filteredResults() {
    if (!currentRun) return [];
    const riskFilter = elements.filterRisk.value;
    const statusFilter = elements.filterStatus.value;
    const stageFilter = elements.filterStage.value;
    const query = elements.search.value.trim().toLocaleLowerCase("ko");

    return currentRun.results.map(function (result, index) {
      return { result: result, index: index };
    }).filter(function (entry) {
      const result = entry.result;
      if (riskFilter === "risk" && !result.risk) return false;
      if (riskFilter === "benign" && result.risk) return false;
      if (statusFilter === "false-positive" && !result.falsePositive) return false;
      if (statusFilter !== "all" && statusFilter !== "false-positive" && result.status !== statusFilter) return false;
      if (stageFilter === "none" && result.blockedAt) return false;
      if (stageFilter !== "all" && stageFilter !== "none" && result.blockedAt !== stageFilter) return false;
      if (query && !(result.title + " " + result.type + " " + result.description).toLocaleLowerCase("ko").includes(query)) return false;
      return true;
    });
  }

  function renderResults() {
    if (!currentRun) {
      elements.resultsBody.innerHTML = "";
      elements.resultsEmpty.hidden = false;
      elements.resultCount.textContent = "실행 결과가 없습니다.";
      return;
    }

    const matches = filteredResults();
    elements.resultCount.textContent = matches.length + " / " + currentRun.results.length + "개 결과 표시";
    elements.resultsEmpty.hidden = matches.length > 0;
    elements.resultsEmpty.textContent = matches.length ? "" : "선택한 조건에 맞는 결과가 없습니다. 필터를 조정해 보세요.";
    elements.resultsBody.innerHTML = matches.map(function (entry) {
      const result = entry.result;
      const status = resultStatus(result);
      const expanded = expandedRows.has(entry.index);
      const statusClass = status.className;
      const row = '<tr>' +
        '<td><span class="rep-tag">R' + result.run + '</span></td>' +
        '<td><span class="case-title">' + escapeHtml(result.title) + '</span><span class="case-type">' + escapeHtml(result.type) + '</span></td>' +
        '<td>' + (result.risk ? '<span class="status-pill unsafe">위험</span>' : '<span class="stage-label">정상</span>') + '</td>' +
        '<td><span class="status-pill ' + escapeHtml(statusClass) + '">' + escapeHtml(status.label) + '</span></td>' +
        '<td><span class="stage-label ' + (result.blockedAt ? "" : "none") + '">' + escapeHtml(stageText(result.blockedAt)) + '</span></td>' +
        '<td><button class="detail-button" type="button" data-detail="' + entry.index + '" aria-expanded="' + String(expanded) + '">' + (expanded ? "닫기" : "상세") + '</button></td>' +
      '</tr>';
      if (!expanded) return row;
      return row + '<tr class="detail-row"><td colspan="6">' +
        '<span class="detail-label">SIMULATED OUTPUT</span>' + escapeHtml(result.output) +
        '<br><span class="detail-label">판정 근거</span>' + escapeHtml(result.reason) +
        (result.canaryExposed ? '<br><span class="detail-label">합성 표식</span>' + escapeHtml(window.SimLab.canaryLabel) : '') +
        '</td></tr>';
    }).join("");
  }

  function renderHistory() {
    if (!history.length) {
      elements.historyList.innerHTML = '<div class="history-empty">저장된 실행이 없습니다. 실험 또는 프리셋 비교를 실행하면 최근 기록이 이 브라우저에 남습니다.</div>';
      return;
    }
    elements.historyList.innerHTML = history.map(function (record, index) {
      const run = record.run;
      const summary = run.summary;
      return '<article class="history-row">' +
        '<div class="history-name">' + escapeHtml(record.label || presetNameFor(run.config)) + '</div>' +
        '<div class="history-date">' + escapeHtml(formatDate(run.createdAt, true)) + '</div>' +
        '<div class="history-meta">' + run.repetitions + '회 · 차단 ' + formatPercent(summary.attackBlockRate) + '</div>' +
        '<div class="history-actions">' +
          '<button class="small-button" type="button" data-history-open="' + index + '">불러오기</button>' +
          '<button class="small-button" type="button" data-export-json="' + index + '">JSON</button>' +
          '<button class="small-button" type="button" data-export-csv="' + index + '">CSV</button>' +
        '</div>' +
      '</article>';
    }).join("");
  }

  function addToHistory(run, label) {
    history = [{ run: run, label: label }, ...history.filter(function (record) {
      return record.run.id !== run.id;
    })].slice(0, HISTORY_LIMIT);
    persistHistory();
    renderHistory();
  }

  function runLabel(run) {
    return presetNameFor(run.config) + " · " + run.repetitions + "회";
  }

  function executeRun() {
    elements.runButton.disabled = true;
    elements.runStatus.textContent = "합성 사례를 로컬에서 계산하고 있습니다…";
    window.requestAnimationFrame(function () {
      try {
        const run = window.SimLab.runSuite(Object.assign({}, config), Number(elements.repetitions.value));
        currentRun = run;
        expandedRows.clear();
        renderReadout(run);
        renderResults();
        addToHistory(run, runLabel(run));
        elements.runStatus.textContent = "실행 완료 · " + run.results.length + "개 판정 기록 · 외부 전송 없음";
      } catch (error) {
        elements.runStatus.textContent = "실행에 실패했습니다. 페이지를 새로고침한 뒤 다시 시도해 주세요.";
      } finally {
        elements.runButton.disabled = false;
      }
    });
  }

  function comparePresets() {
    elements.compareButton.disabled = true;
    elements.compareFeedback.textContent = "세 프리셋을 같은 조건으로 비교하고 있습니다…";
    window.requestAnimationFrame(function () {
      try {
        const comparisons = window.SimLab.comparePresets(Number(elements.repetitions.value));
        renderComparison(comparisons);
        comparisons.forEach(function (item) {
          addToHistory(item.run, item.preset.name + " · 프리셋 비교");
        });
        elements.compareFeedback.textContent = "비교 완료 · " + comparisons.length + "개 프리셋 · 각 " + Number(elements.repetitions.value) + "회 반복";
      } catch (error) {
        elements.compareFeedback.textContent = "비교를 실행하지 못했습니다. 다시 시도해 주세요.";
      } finally {
        elements.compareButton.disabled = false;
      }
    });
  }

  function csvCell(value) {
    let text = String(value == null ? "" : value);
    if (/^[=+\-@]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }

  function downloadFile(filename, content, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.hidden = true;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function safeFilename(value) {
    return String(value || "run").replace(/[^a-zA-Z0-9가-힣_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "run";
  }

  function exportRun(run, format) {
    if (!run) {
      showToast("내보낼 실행 기록이 없습니다.");
      return;
    }
    const fileBase = "ai-safety-lab-" + safeFilename(run.id);
    if (format === "json") {
      downloadFile(fileBase + ".json", JSON.stringify(run, null, 2), "application/json;charset=utf-8");
      showToast("JSON 기록을 내려받았습니다.");
      return;
    }
    const headers = ["반복", "사례 ID", "사례명", "유형", "위험 사례", "판정", "차단 단계", "정책 위반", "합성 표식 노출", "과잉 차단", "모의 응답", "판정 근거"];
    const rows = run.results.map(function (result) {
      return [
        result.run, result.caseId, result.title, result.type, result.risk ? "예" : "아니오",
        result.falsePositive ? "과잉 차단" : (statusLabels[result.status] || result.status),
        stageText(result.blockedAt), result.policyViolation ? "예" : "아니오",
        result.canaryExposed ? "예" : "아니오", result.falsePositive ? "예" : "아니오",
        result.output, result.reason,
      ].map(csvCell).join(",");
    });
    downloadFile(fileBase + ".csv", "\uFEFF" + [headers.map(csvCell).join(",")].concat(rows).join("\r\n"), "text/csv;charset=utf-8");
    showToast("CSV 기록을 내려받았습니다.");
  }

  function exportGeminiRun(format) {
    if (!geminiRun) {
      showToast("내보낼 Gemini 실험 결과가 없습니다.");
      return;
    }
    const base = "gemini-live-" + safeFilename(geminiRun.id);
    if (format === "json") {
      downloadFile(base + ".json", JSON.stringify(geminiRun, null, 2), "application/json;charset=utf-8");
      showToast("합성 Gemini 실험 결과를 JSON으로 내려받았습니다.");
      return;
    }
    const headers = ["반복", "사례 ID", "사례명", "판정", "합성 표식 감지", "표식 노출", "모델", "응답 일부"];
    const rows = geminiRun.results.map(function (result) {
      return [
        result.run, result.caseId, result.title, result.status,
        result.canaryDetected ? "예" : "아니오", result.canaryExposed ? "예" : "아니오",
        geminiRun.model, result.output,
      ].map(csvCell).join(",");
    });
    downloadFile(base + ".csv", "\uFEFF" + [headers.map(csvCell).join(",")].concat(rows).join("\r\n"), "text/csv;charset=utf-8");
    showToast("합성 Gemini 실험 결과를 CSV로 내려받았습니다.");
  }

  function openHistory(index) {
    const record = history[index];
    if (!record) return;
    currentRun = record.run;
    config = Object.assign({}, record.run.config);
    elements.repetitions.value = String(record.run.repetitions);
    updateConfigButtons();
    expandedRows.clear();
    renderReadout(currentRun);
    renderResults();
    elements.runStatus.textContent = "브라우저 기록을 불러왔습니다 · " + (record.label || presetNameFor(config));
    document.getElementById("results-title").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  elements.guardButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const key = button.dataset.guard;
      config[key] = !config[key];
      updateConfigButtons();
      elements.runStatus.textContent = "설정 변경됨 · 다음 실행에 적용됩니다.";
    });
  });

  elements.runButton.addEventListener("click", executeRun);
  elements.compareButton.addEventListener("click", comparePresets);
  elements.geminiRunButton.addEventListener("click", runGeminiExperiment);
  elements.geminiExportJson.addEventListener("click", function () { exportGeminiRun("json"); });
  elements.geminiExportCsv.addEventListener("click", function () { exportGeminiRun("csv"); });
  [elements.adultConfirm, elements.geminiDataConsent].forEach(function (control) {
    control.addEventListener("change", updateGeminiRunButton);
  });
  [elements.filterRisk, elements.filterStatus, elements.filterStage].forEach(function (control) {
    control.addEventListener("change", renderResults);
  });
  elements.search.addEventListener("input", renderResults);

  elements.resultsBody.addEventListener("click", function (event) {
    const button = event.target.closest("[data-detail]");
    if (!button) return;
    const index = Number(button.dataset.detail);
    if (expandedRows.has(index)) expandedRows.delete(index);
    else expandedRows.add(index);
    renderResults();
    const nextButton = elements.resultsBody.querySelector('[data-detail="' + index + '"]');
    if (nextButton) nextButton.focus();
  });

  elements.historyList.addEventListener("click", function (event) {
    const openButton = event.target.closest("[data-history-open]");
    const jsonButton = event.target.closest("[data-export-json]");
    const csvButton = event.target.closest("[data-export-csv]");
    if (openButton) openHistory(Number(openButton.dataset.historyOpen));
    if (jsonButton) {
      const record = history[Number(jsonButton.dataset.exportJson)];
      exportRun(record && record.run, "json");
    }
    if (csvButton) {
      const record = history[Number(csvButton.dataset.exportCsv)];
      exportRun(record && record.run, "csv");
    }
  });

  elements.clearHistory.addEventListener("click", function () {
    if (!history.length) {
      showToast("지울 브라우저 기록이 없습니다.");
      return;
    }
    if (!window.confirm("이 브라우저에 저장된 최근 실행 기록을 모두 지울까요? 현재 화면의 실행 결과는 유지됩니다.")) return;
    history = [];
    try {
      window.localStorage.removeItem(HISTORY_KEY);
      renderHistory();
      showToast("브라우저의 최근 실행 기록을 지웠습니다.");
    } catch (error) {
      showToast("브라우저 저장소를 지우지 못했습니다.");
    }
  });

  if (!window.SimLab || !Array.isArray(window.SimLab.cases) || !Array.isArray(window.SimLab.presets)) {
    elements.runButton.disabled = true;
    elements.compareButton.disabled = true;
    elements.runStatus.textContent = "로컬 시뮬레이터를 불러오지 못했습니다. 페이지를 새로고침해 주세요.";
    elements.caseCount.textContent = "오류";
    return;
  }

  setupRepetitions();
  elements.caseCount.textContent = String(window.SimLab.cases.length).padStart(2, "0");
  updateConfigButtons();
  renderInitialCompareCards();
  renderHistory();
  renderResults();
  checkGeminiStatus();
})();
