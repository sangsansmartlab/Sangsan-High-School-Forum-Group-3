const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const {
  createRunLimiter,
  getExperimentStatus,
  getGeminiApiKeys,
  runGeminiSuite,
  validateRunOptions,
} = require("./gemini-experiment");

const publicDir = path.join(__dirname, "public");
const port = Number(process.env.PORT) || 5000;
const host = "0.0.0.0";
const geminiRunLimiter = createRunLimiter({ maxRuns: 2, windowMs: 60 * 60 * 1000 });
const maxRequestBytes = 8192;
let currentGeminiProgress = null;

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
};

function send(res, status, body, contentType = "text/plain; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": contentType,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Cache-Control": "no-store",
    "Content-Security-Policy":
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'",
  });
  res.end(body);
}

function sendJson(res, status, value) {
  send(res, status, JSON.stringify(value), "application/json; charset=utf-8");
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let tooLarge = false;

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > maxRequestBytes) {
        tooLarge = true;
        chunks.length = 0;
      } else if (!tooLarge) {
        chunks.push(chunk);
      }
    });

    req.on("end", () => {
      if (tooLarge) {
        reject(Object.assign(new Error("Request body is too large."), { statusCode: 413 }));
        return;
      }
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch {
        reject(Object.assign(new Error("Request body must be valid JSON."), { statusCode: 400 }));
      }
    });

    req.on("error", () => {
      reject(Object.assign(new Error("Request body could not be read."), { statusCode: 400 }));
    });
  });
}

const server = http.createServer(async (req, res) => {
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  } catch {
    send(res, 400, "Bad request");
    return;
  }

  if (pathname === "/healthz") {
    send(res, 200, JSON.stringify({ ok: true, mode: "local-synthetic-simulation" }), "application/json; charset=utf-8");
    return;
  }

  if (pathname === "/api/gemini/status") {
    if (req.method !== "GET" && req.method !== "HEAD") {
      sendJson(res, 405, { error: "Method not allowed." });
      return;
    }
    sendJson(res, 200, getExperimentStatus());
    return;
  }

  if (pathname === "/api/gemini/progress") {
    if (req.method !== "GET" && req.method !== "HEAD") {
      sendJson(res, 405, { error: "Method not allowed." });
      return;
    }
    sendJson(res, 200, currentGeminiProgress || {
      status: "idle",
      phase: "idle",
      completed: 0,
      total: 0,
      currentCase: null,
      model: null,
      message: "실행 대기 중",
    });
    return;
  }

  if (pathname === "/api/gemini/run") {
    if (req.method !== "POST") {
      sendJson(res, 405, { error: "Method not allowed." });
      return;
    }
    const apiKeys = getGeminiApiKeys();
    if (!apiKeys.length) {
      sendJson(res, 503, { error: "Gemini API 키가 설정되지 않았습니다." });
      return;
    }
    if (!req.headers["content-type"]?.toLowerCase().startsWith("application/json")) {
      sendJson(res, 415, { error: "JSON 요청만 허용됩니다." });
      return;
    }

    let options;
    try {
      options = validateRunOptions(await readJsonBody(req));
    } catch (error) {
      sendJson(res, error.statusCode || 400, { error: error.message });
      return;
    }

    const reservation = geminiRunLimiter.acquire();
    if (!reservation.ok) {
      sendJson(res, reservation.statusCode, { error: reservation.message });
      return;
    }

    const expectedTotal = (options.caseIds ? options.caseIds.length : getExperimentStatus().caseCount) *
      options.repetitions;
    currentGeminiProgress = {
      status: "running",
      phase: "starting",
      completed: 0,
      total: expectedTotal,
      currentCase: null,
      model: getExperimentStatus().model,
      message: "Gemini 실험 준비 중",
    };
    const progress = currentGeminiProgress;

    try {
      const run = await runGeminiSuite(options, {
        apiKeys,
        onProgress: (update) => Object.assign(progress, update),
      });
      Object.assign(progress, {
        status: "completed",
        phase: "completed",
        completed: run.summary.total,
        total: run.summary.total,
        currentCase: null,
        model: run.modelsUsed[run.modelsUsed.length - 1] || run.model,
        message: `실험 완료 · ${run.summary.total}/${run.summary.total}`,
      });
      sendJson(res, 200, run);
    } catch (error) {
      const status = error.statusCode || 502;
      const message = error.publicMessage || "Gemini 실험 요청에 실패했습니다. 잠시 후 다시 확인해 주세요.";
      Object.assign(progress, {
        status: "failed",
        phase: "failed",
        currentCase: progress.currentCase || null,
        message,
      });
      sendJson(res, status, { error: message });
    } finally {
      reservation.release();
    }
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "Method not allowed");
    return;
  }

  const requestedPath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.resolve(publicDir, `.${requestedPath}`);
  if (!filePath.startsWith(`${publicDir}${path.sep}`)) {
    send(res, 404, "Not found");
    return;
  }

  fs.readFile(filePath, (error, contents) => {
    if (error) {
      send(res, error.code === "ENOENT" ? 404 : 500, error.code === "ENOENT" ? "Not found" : "Server error");
      return;
    }
    const type = contentTypes[path.extname(filePath)] || "application/octet-stream";
    res.writeHead(200, {
      "Content-Type": type,
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
      "Cache-Control": "no-store",
      "Content-Security-Policy":
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'",
    });
    if (req.method === "HEAD") {
      res.end();
    } else {
      res.end(contents);
    }
  });
});

server.listen(port, host, () => {
  console.log(`AI Safety Lab listening on http://${host}:${port}`);
});

function closeServer() {
  server.close(() => process.exit(0));
}

process.on("SIGTERM", closeServer);
process.on("SIGINT", closeServer);
