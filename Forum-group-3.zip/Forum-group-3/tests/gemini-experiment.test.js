const test = require("node:test");
const assert = require("node:assert/strict");
const {
  CANARY,
  cases,
  createRunLimiter,
  getExperimentStatus,
  getGeminiApiKeys,
  getModelChain,
  runGeminiSuite,
  validateRunOptions,
} = require("../gemini-experiment");

function options(overrides = {}) {
  return validateRunOptions({
    repetitions: 1,
    modelGuard: true,
    outputGuard: true,
    adultConfirmed: true,
    dataConsent: true,
    ...overrides,
  });
}

function responseWithText(text, extra = {}) {
  return new Response(JSON.stringify({
    candidates: [{
      content: { parts: [{ text }] },
      finishReason: "STOP",
    }],
    ...extra,
  }), { status: 200, headers: { "Content-Type": "application/json" } });
}

test("live suite is limited to four fixed benign synthetic requests", () => {
  assert.equal(cases.length, 4);
  assert.ok(cases.every((item) => item.type === "정상 요청"));
  assert.ok(cases.every((item) => typeof item.prompt === "string" && item.prompt.length < 200));
});

test("numbered secret slots are read in order and status exposes only their count", () => {
  const env = {
    GEMINI_API_KEY: " primary-test-key ",
    GEMINI_API_KEY_3: "backup-test-key",
    GEMINI_API_KEY_6: "outside-supported-slots",
  };
  assert.deepEqual(getGeminiApiKeys(env), [
    { slot: 1, key: "primary-test-key" },
    { slot: 3, key: "backup-test-key" },
  ]);
  const status = getExperimentStatus(env);
  assert.equal(status.configured, true);
  assert.equal(status.configuredKeyCount, 2);
  assert.deepEqual(status.models, [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
  ]);
  assert.ok(!JSON.stringify(status).includes("primary-test-key"));
  assert.ok(!JSON.stringify(status).includes("backup-test-key"));
});

test("a configured Gemini model remains first in the fallback chain", () => {
  assert.deepEqual(getModelChain("gemini-3.5-flash-lite"), [
    "gemini-3.5-flash-lite",
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.1-flash-lite",
  ]);
});

test("live runs require adult and data-processing confirmations", () => {
  assert.throws(() => options({ adultConfirmed: false }), /성인 이용/);
  assert.throws(() => options({ dataConsent: false }), /성인 이용/);
  assert.throws(() => options({ repetitions: 4 }), /1~3회/);
  assert.throws(() => options({ modelGuard: "true" }), /가드레일 설정/);
  assert.throws(() => options({ caseIds: ["unknown-case"] }), /합성 사례 설정/);
  assert.throws(() => options({ caseIds: ["benign-question", "benign-question"] }), /합성 사례 설정/);
});

test("a selected case sends exactly one fixed Gemini request", async () => {
  const captured = [];
  const run = await runGeminiSuite(options({ caseIds: ["benign-question"] }), {
    apiKey: "unit-test-key",
    fetchImpl: async (url, init) => {
      captured.push({ url, request: JSON.parse(init.body) });
      return responseWithText("4입니다.");
    },
  });

  assert.equal(captured.length, 1);
  assert.equal(run.results.length, 1);
  assert.deepEqual(run.config.caseIds, ["benign-question"]);
  assert.equal(run.results[0].caseId, "benign-question");
  assert.equal(captured[0].request.contents[0].parts[0].text, cases[0].prompt);
});

test("authentication failure falls through to the next key and reuses the working key", async () => {
  const attemptedKeys = [];
  const run = await runGeminiSuite(options({
    caseIds: ["benign-question", "benign-summary"],
  }), {
    apiKeys: [
      { slot: 1, key: "invalid-test-key" },
      { slot: 2, key: "backup-test-key" },
    ],
    fetchImpl: async (url, init) => {
      attemptedKeys.push(init.headers["x-goog-api-key"]);
      if (attemptedKeys.length === 1) return new Response("{}", { status: 403 });
      return responseWithText("정상 답변입니다.");
    },
  });

  assert.deepEqual(attemptedKeys, ["invalid-test-key", "backup-test-key", "backup-test-key"]);
  assert.deepEqual(run.results.map((result) => result.keySlot), [2, 2]);
  assert.ok(!JSON.stringify(run).includes("invalid-test-key"));
  assert.ok(!JSON.stringify(run).includes("backup-test-key"));
});

test("timeouts do not trigger another key request", async () => {
  let attempts = 0;
  const timeout = Object.assign(new Error("timeout"), { name: "TimeoutError" });
  await assert.rejects(
    runGeminiSuite(options({ caseIds: ["benign-question"] }), {
      apiKeys: [
        { slot: 1, key: "first-test-key" },
        { slot: 2, key: "second-test-key" },
      ],
      fetchImpl: async () => {
        attempts += 1;
        throw timeout;
      },
    }),
    (error) => error.statusCode === 504,
  );
  assert.equal(attempts, 1);
});

test("model quota exhaustion switches models and reports live progress", async () => {
  const attemptedModels = [];
  const progress = [];
  const run = await runGeminiSuite(options({
    caseIds: ["benign-question", "benign-summary"],
  }), {
    apiKey: "unit-test-key",
    models: ["gemini-test-primary", "gemini-test-backup"],
    onProgress: (event) => progress.push(event),
    fetchImpl: async (url) => {
      const model = decodeURIComponent(url.match(/\/models\/([^:]+)/)[1]);
      attemptedModels.push(model);
      if (model === "gemini-test-primary") return new Response("{}", { status: 429 });
      return responseWithText("합성 사례에 대한 정상 응답입니다.");
    },
  });

  assert.deepEqual(attemptedModels, [
    "gemini-test-primary",
    "gemini-test-backup",
    "gemini-test-backup",
  ]);
  assert.deepEqual(run.modelsUsed, ["gemini-test-backup"]);
  assert.deepEqual(run.results.map((result) => result.model), [
    "gemini-test-backup",
    "gemini-test-backup",
  ]);
  assert.ok(progress.some((event) => event.phase === "model-fallback"));
  assert.deepEqual(
    progress.filter((event) => event.phase === "case-complete").map((event) => [event.completed, event.total]),
    [[1, 2], [2, 2]],
  );
});

test("suite makes only fixed Gemini requests and scans output for the synthetic marker", async () => {
  const captured = [];
  const run = await runGeminiSuite(options(), {
    apiKey: "unit-test-key",
    model: "gemini-test",
    now: () => 1234,
    fetchImpl: async (url, init) => {
      captured.push({ url, init, request: JSON.parse(init.body) });
      return responseWithText("정상 답변입니다.");
    },
  });

  assert.equal(run.results.length, 4);
  assert.equal(run.summary.responseCount, 4);
  assert.equal(run.summary.canaryLeakCount, 0);
  assert.ok(captured.every(({ url }) => !url.includes("unit-test-key")));
  assert.ok(captured.every(({ init }) => init.headers["x-goog-api-key"] === "unit-test-key"));
  assert.ok(captured.every(({ request }) => !request.tools));
  assert.ok(captured.every(({ request }) => !request.contents[0].parts[0].text.includes(CANARY)));
  assert.ok(captured.every(({ request }) => request.systemInstruction.parts[0].text.includes(CANARY)));
});

test("output guard redacts a synthetic marker and records containment without returning it", async () => {
  const run = await runGeminiSuite(options({ repetitions: 1 }), {
    apiKey: "unit-test-key",
    fetchImpl: async () => responseWithText(`답변 ${CANARY}`),
  });
  const result = run.results[0];
  assert.equal(result.status, "redacted");
  assert.equal(result.canaryDetected, true);
  assert.equal(result.canaryExposed, false);
  assert.ok(!result.output.includes(CANARY));
});

test("marker exposure is counted but the raw synthetic marker is still hidden", async () => {
  const run = await runGeminiSuite(options({ outputGuard: false }), {
    apiKey: "unit-test-key",
    fetchImpl: async () => responseWithText(`답변 ${CANARY}`),
  });
  assert.equal(run.summary.canaryLeakCount, 4);
  assert.equal(run.results[0].status, "leaked");
  assert.ok(!run.results[0].output.includes(CANARY));
});

test("provider-blocked responses are recorded without exposing provider payloads", async () => {
  const run = await runGeminiSuite(options(), {
    apiKey: "unit-test-key",
    fetchImpl: async () => new Response(JSON.stringify({
      promptFeedback: { blockReason: "SAFETY" },
      candidates: [],
    }), { status: 200 }),
  });
  assert.equal(run.summary.blockedCount, 4);
  assert.equal(run.results[0].providerBlockReason, "SAFETY");
  assert.match(run.results[0].output, /응답을 생성하지 않았습니다/);
});

test("limiter prevents concurrent runs and caps hourly attempts", () => {
  let clock = 1000;
  const limiter = createRunLimiter({ maxRuns: 2, windowMs: 60_000, now: () => clock });
  const first = limiter.acquire();
  assert.equal(first.ok, true);
  assert.equal(limiter.acquire().statusCode, 409);
  first.release();
  const second = limiter.acquire();
  assert.equal(second.ok, true);
  second.release();
  assert.equal(limiter.acquire().statusCode, 429);
  clock += 60_000;
  assert.equal(limiter.acquire().ok, true);
});
