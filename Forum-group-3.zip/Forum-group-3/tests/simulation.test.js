const test = require("node:test");
const assert = require("node:assert/strict");
const simulator = require("../public/simulation.js");

test("suite contains only the eight predefined synthetic cases", () => {
  assert.equal(simulator.cases.length, 8);
  assert.ok(simulator.cases.every((item) => item.id && item.description));
  assert.ok(simulator.cases.some((item) => item.containsCanary));
});

test("unprotected comparison baseline shows synthetic risk without external actions", () => {
  const run = simulator.runSuite({}, 3);
  assert.equal(run.summary.total, 24);
  assert.equal(run.summary.attackBlockRate, 0);
  assert.equal(run.summary.canaryLeakCount, 3);
  assert.equal(run.summary.unsafeCount, 12);
  assert.equal(run.summary.falsePositiveCount, 0);
});

test("layered defenses block risky fixtures and output scanning contains the canary", () => {
  const run = simulator.runSuite({ inputGuard: true, modelGuard: true, outputGuard: true }, 3);
  assert.equal(run.summary.attackBlockRate, 1);
  assert.equal(run.summary.canaryLeakRate, 0);
  assert.equal(run.summary.unsafeCount, 0);
  assert.equal(run.summary.reproducibility, 1);
});

test("input filtering demonstrates the planned false-positive tradeoff", () => {
  const run = simulator.runSuite({ inputGuard: true }, 1);
  assert.equal(run.summary.falsePositiveCount, 1);
  assert.equal(run.summary.falsePositiveRate, 0.25);
});

test("the model policy catches an untrusted document case missed by input scanning", () => {
  const run = simulator.runSuite({ inputGuard: true, modelGuard: true }, 1);
  const documentCase = run.results.find((item) => item.caseId === "document-injection");
  assert.equal(documentCase.status, "blocked");
  assert.equal(documentCase.blockedAt, "model");
});

test("repetition count is bounded and comparison returns three presets", () => {
  assert.equal(simulator.runSuite({}, 50).repetitions, 10);
  assert.equal(simulator.comparePresets(2).length, 3);
});
